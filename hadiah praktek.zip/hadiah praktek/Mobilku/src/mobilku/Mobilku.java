/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mobilku;

import java.awt.*;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.*;
public class Mobilku extends Frame implements ActionListener{
    int x = 100;
    int y = 100;   
public static void main(String[] args) {
    Frame frame = new Mobilku();
    frame.setSize(640, 480);
    frame.setVisible(true);
}
public Mobilku() { 
// end program when window is closed    
    WindowListener l = new WindowAdapter() {
    public void windowClosing(WindowEvent ev) {
    System.exit(0);
    }
    };

this.addWindowListener(l);
// mouse event handler
MouseListener mouseListener = new MouseAdapter() {
public void mouseClicked(MouseEvent ev) {
    x = ev.getX();
    y = ev.getY();
    repaint();
}
};
addMouseListener(mouseListener);
}


public void paint(Graphics g) {
setBackground (Color.GRAY);

g.setColor(Color.white);
g.setColor(Color.blue);
g.fillRect(150,150,220,55);
g.fillRect(150,205,300,65);
g.drawLine(x +250, 150 , 150 , 150);
g.drawLine(x +350, 270 , 150 , 150);
g.drawLine(x +50,150, 150,270);
g.drawLine(x +250,150, 350,205);
g.drawLine(x +300,205, 400,270);
g.drawOval(195, 235, 60, 60);
g.drawOval(320, 235, 60, 60);
g.setColor(Color.red);
g.fillOval(195, 235, 60, 60);
g.fillOval(320, 235, 60, 60);
g.setColor(Color.black);
g.drawString("Gambar diatas adalah sebuah mobil, dan namaku Nurul Fitrah",170,330);
}
public void actionPerformed(ActionEvent ev) {
String command = ev.getActionCommand();
if ("Close".equals(command)) {
System.exit(0);
}
}
}




    

